/*
下面我们以一个实际用例来看下如何利用 Cypress 做接口测试。
1.启动演示项目
//在您的目标文件夹下，clone项目
E:\>git clone https://github.com/cypress-io/cypress-example-recipes.git

//克隆成功后，依次执行如下命令
E:\>cd cypress-example-recipes
E:\cypress-example-recipes>cd examples
E:\cypress-example-recipes\examples>cd logging-in-html-web-forms
E:\cypress-example-recipes\examples\logging-in-html-web-forms>npm start
在浏览器中访问http://localhost:7077/ 以确认项目启动成功。
2.编写测试用例
在Integration文件夹下，创建测试文件testAPI.js。
//testAPI.js
/// <reference types="cypress" />

describe('使用接口直接测试', function () {
    const username = 'jane.lane'
    const password = 'password123'

it('通过cy.request直接发送请求测试', function () {
//POST请求
        cy.request({
            method: 'POST',
            url: '/login',
            form: true,
            body: {
                username,
                password
            },
        })

	//GET请求
        cy.request({
            method: 'GET',
            url: '/dashboard'
        })
            .its('body')
            .should('contain', 'jane.lane')

        cy.request('/admin')
            .its('body')
            .should('include', '<h1>Admin</h1>')
    })

})
3.在packagae.json文件的scripts模块增加如下内容。
//仅展示scripts的更改部分。
"scripts": {
    "apiTest": "../../node_modules/.bin/cypress run --spec './cypress/integration/testAPI.js'"
  }
4.运行测试
E:\cypress-example-recipes\examples\logging-in-html-web-forms>yarn apiTest
运行结束后

*/