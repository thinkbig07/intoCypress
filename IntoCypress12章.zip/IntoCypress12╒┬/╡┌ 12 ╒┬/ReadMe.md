//本实例用于附上书中代码，以减少您的学习成本。
1. 先根据书中的步骤，建立起您的 Mock server。
2. 启动 Mock server。
node testHttpStatusCode.js
3.打开您的测试项目（您的真实测试项目，如果没有，您可以直接用 mockserverSample）。 在你的测试代码中调用 Mock Server提供的方法即可（您的 mock server 以 https 的方式启动，故可以通过 http 请求直接访问。您可以将您的 Mock Server 部署到您的项目的根目录下以便使用同一个超域来避免同源策略导致的测试失败）。
3.本章实现了 swagger API的搭建（书中未提及）。  您启动Mock Server 后，可以直接访问https://localhost:3002/api-docs/#/ 来尝试 swagger api。

 4.如果您用 chrome 访问，请您在使用前首先在浏览器中输入chrome://flags/#allow-insecure-localhost
，然后在弹出的第一个选项中选择 enable即可使用。