var fs = require('fs'),
  https = require('https'),
  jsonServer = require('json-server'),
  server = jsonServer.create(),
  router = jsonServer.router('db.json'),
  middlewares = jsonServer.defaults();

var options = {
  key: fs.readFileSync('./key.pem'),
  cert: fs.readFileSync('./cert.pem')
};

//自定义 api/user 这个路由的 http status code。
//本例简单判断， POST 请求返回 400， 其它请求返回 200
server.post('/api/user', (req, res) => {
    //这里写您希望的处理逻辑
    if (req.method === 'POST') {
          res.status(400).jsonp({
            error: "Bad userId"
          });
        }else {
        res.status(200).jsonp(res.locals.data);
      }
    });


server.use(middlewares);
server.use(router);

https.createServer(options, server).listen(3002, function() {
  console.log("json-server started on port " + 3002);
});
