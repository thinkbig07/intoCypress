//pause 用法
//testLogin.js
/// <reference types="cypress" />

describe('登录', function () {
  // 此用户名和密码为本地服务器默认。
  const username = 'jane.lane'
  const password = 'password123'

  context('HTML表单登录测试', function () {

    it('登录成功，跳转到dashboard页', function () {
      cy.visit('http://localhost:7077/login')
      cy.get('input[name=username]').type(username)
      cy.get('input[name=password]').type(password)
	// 暂停测试。	
	cy.pause()
      cy.get('form').submit()

      // 断言，验证登录成功则跳转到/dashboard页面。
      // 断言，验证用户名存在。
      cy.url().should('include', '/dashboard')
      cy.get('h1').should('contain', 'jane.lane')
    })
  })
})


// debug 用法
//testLogin.js
/// <reference types="cypress" />

describe('登录', function () {
  // 此用户名和密码为本地服务器默认。
  const username = 'jane.lane'
  const password = 'password123'

  context('HTML表单登录测试', function () {

    it('登录成功，跳转到dashboard页', function () {
      cy.visit('http://localhost:7077/login')
      cy.get('input[name=username]').type(username)
      cy.get('input[name=password]').type(password)
	// Debug测试。	
      cy.get('form').debug().submit()

      // 断言，验证登录成功则跳转到/dashboard页面。
      // 断言，验证用户名存在。
      cy.url().should('include', '/dashboard')
      cy.get('h1').should('contain', 'jane.lane')
    })
  })
})