/*
首先，建立一个文件夹，并在其中建立您在不同环境用到的变量及变量值。举例来说，在“Cypress/config”文件夹下建立两个文件，分别命名为cypress.dev.json和cypress.qa.json。内容分别如下：


//cypress.dev.json
{
    "baseUrl":"http://localhost:7077/login",
    "env":{
        "username":"jane.lane",
        "password":"password123"
    }

}

//cypress.qa.json
{
    "baseUrl":"http://localhost:7077/login",
    "env":{
        "username":"wrongUser",
        "password":"wrongPassword"
    }

}

其次，在plugins/index.js中更改配置如下：
*/

//plugins/index.js
const fs = require('fs-extra')
const path = require('path')

function getConfigurationByFile (file) {
  const pathToConfigFile = path.resolve('..', 'cypress/cypress/config', `cypress.${file}.json`)
  return fs.readJson(pathToConfigFile)
}

// plugins file
module.exports = (on, config) => {
  // 指定一个环境配置，如没有指定，则使用cypress.dev.json
  const file = config.env.configFile || 'dev'

  return getConfigurationByFile(file)
}

/*
最后，运行时指定configFile的值即可（本例指定环境为qa）。
//假设您的项目根目录是E:\Cypress
E:\Cypress>yarn cypress open --env configFile=qa
*/

//运行时动态指定环境变量
//使用cypress.env.json
//首先，在cypress.json中，更改如下：
//首先，建立一个变量targetEnv，并给定默认值dev环境。
//其次，更改env的代码块，把您的环境及其环境变量按格式写入。

/*
"targetEnv":"dev"
"env": {
    "dev": {
      "username": "iTesting",
      "password": "weChat",
      "Url": "http://localhost:5883"
    },
    "qa": {
      "username": "wrongUser",
      "password": "wrongPassword",
      "Url": "https://qa.test.com:5883"
    }
}
*/

//其次，更改“support/index.js”文件。
//接受用户的参数testEnv。如果没有指定testEnv，则使用cypress.json中targetEnv的设置。
//根据最终的环境变量，重写url。
beforeEach(() => {
  const targetEnv = Cypress.env('testEnv') || Cypress.config('targetEnv')
  cy.log(`测试环境为: \n ${JSON.stringify(targetEnv)}`)
  cy.log(`测试环境详细配置为: \n ${JSON.stringify(Cypress.env(targetEnv))}`)
  Cypress.config('baseUrl', Cypress.env(targetEnv).Url)
})

//最后，在您运行时，指定要运行的测试环境。
//指定测试环境为qa
//E:\Cypress>yarn cypress open --env testEnv=qa