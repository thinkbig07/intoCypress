/*下面举例介绍下使用自定义命令替换10.10节中的PageObject模式用例。
1.在cypress/support/commands.js中，添加如下定义：
*/
Cypress.Commands.add('login', (username, password) => {
    Cypress.log({
        name: 'login',
        message: `${username} | ${password}`,
    })

    return cy.request({
        method: 'POST',
        url: '/login',
        form: true,
        body: {
            username,
            password,
        },
    })
})

/*
2.无需PageObject模型，直接在integration文件夹下建立testLogin.js测试文件。
*/

//testLogin.js
/// <reference types="cypress" />

describe('登录测试，自定义命令行模式', function () {
    const username = 'jane.lane'
    const password = 'password123'

    beforeEach(function () {
        cy.login(username, password)
    })

    it('可以访问受保护页', function () {
        //cy.request（）登录成功后，Cypress会自动保存session cookie，
        //所以我们可以访问登录后才能访问的页面。
        cy.visit('/dashboard')
        cy.url().should('eq', 'http://localhost:7077/dashboard')
        cy.get('h1').should('contain', 'jane.lane')
    })
})

/*
最后，笔者介绍下如何重写Cypress内置命令， 以cy.visit()为例。
1.在cypress/support/commands.js中，添加如下定义
*/

Cypress.Commands.overwrite('visit', (originalFn, url) => {
    //仅为演示如何重新内置命令，您可以根据实际需要更改
    //重写visit命令，使每个visit命令都打印一行++符号在console里。

    console.log('++++++++++++++')

    //originalFn代表传入进来的原`visit`命令
    //url是visit里的url地址
    return originalFn(url)
})

/*
2.此后，任何使用到cy.visit的命令，都将在浏览器console里打印出一行“++”符号。
*/