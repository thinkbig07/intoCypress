/// <reference types="cypress" />

import LoginPage from "../pages/login"
import mainPage from "../pages/main"


describe('登录测试，PageObject模式', function () {
    // we can use these values to log in
    const username = 'jane.lane'
    const password = 'password123'

    it('登录成功', function () {
        const loginInstance = new LoginPage()
        loginInstance.visitPage()
        loginInstance.isTargetPage()
        cy.login(username, password)
        cy.url().should('include', '/dashboard')

        const mainInstance = new mainPage()
        mainInstance.isTargetPage()
        mainInstance.welComeText.should('contain', 'jane.lane')
    })

})