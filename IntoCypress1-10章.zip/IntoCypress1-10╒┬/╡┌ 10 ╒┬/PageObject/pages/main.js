import CommonPage from './commonPage'

export default class mainPage extends CommonPage {
    constructor() {
        super()
        this.h1Locator = 'h1'
        this.url = 'http://localhost:7077/dashboard'
    }

    get welComeText() {
        return cy.get(this.h1Locator)
    }
}