export default class CommonPage {
    constructor() {
        //构造函数，可以为空。
        //如果不为空，应该是所有 page 都会用到的变量。
    }

    isTargetPage() {
        cy.url().should('eq', this.url)
    }

}