/*精通挑选待测试用例，指给测试用例添加一个或多个相应描述关键字，在运行时，指定相应的关键字，运行或者排斥测试用例。
Cypress通过插件cypress-select-tests实现了这个功能。步骤如下：
1.安装。
//安装插件
C:\Users\Administrator>npm install --save-dev cypress-select-tests
2.设置。 更改cypress/plugins/index.js文件。
const selectTestsWithGrep = require('cypress-select-tests/grep')
module.exports = (on, config) => {
  on('file:preprocessor', selectTestsWithGrep(config))
}
3.打开项目根目录，在Integration目录下新建testPickToRun.js，如下：
//请参考前面章节，确保您本地的服务已经启动，
/// <reference types="cypress" />

describe("测试登录", function () {
  // 此用户名和密码为本地服务器默认。
  const username = 'jane.lane'
  const password = 'password123'

  context('登录成功，跳转到dashboard页', function () {

    it("['smoke'] 登录用例1", function () {

      cy.visit('http://localhost:7077/login') 
      cy.get('input[name=username]').type(username)
      cy.get('input[name=password]').type(password) 
      cy.get('form').submit()

      // 验证登录成功则跳转到/dashboard页面。

      cy.get('h1').should('contain', 'jane.lane')
    })

    it("[e2e, 'smoke'] 登录用例2", function(){
      cy.log('iTesting')
    })
  })
})

4.指定标签运行，本例指定运行含有“e2e”标签的测试用例。
//切换到项目目录
C:\Users\Administrator>E:

E:\>cd Cypress
E:\Cypress>yarn cypress:open –env grep=e2e
然后在TestRunner中选择测试用例“testPickToRun.js”，点击运行。


可以看到任何含有标签’e2e’的测试用例或者测试套件均会被执行。
Cypress还支持根据文件名来筛选待测试用例。用法如下：
//切换到项目目录
C:\Users\Administrator>E:

E:\>cd Cypress
E:\Cypress>yarn cypress:open –env fgrep=Login
则所有文件名中包含“Login”字符的测试套件均将被运行。
*/