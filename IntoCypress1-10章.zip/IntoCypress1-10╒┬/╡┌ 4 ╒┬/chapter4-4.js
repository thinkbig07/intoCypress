/* 用户自定义报告
自定义测试报告的步骤如下：
1.在cypress.json文件中配置reporter选项，指定reporter文件位置。例如本例中把reporter定义在“iTesting-custom.json”文件中。
{
  "reporter": "reporters/iTesting-custom.js"
}
2.编写您的自定义报告文件。在项目根目录下的cypress文件夹下，创建reporter文件夹，并新建一个文件，命名为“iTesting-custom.js”，代码如下（此自定义报告扩展了内置报告，仅更改了用例成功的显示样式）。
*/
var mocha = require('mocha');
module.exports = MyReporter;

function MyReporter(runner) {
  mocha.reporters.Base.call(this, runner);
  var passes = 0;
  var failures = 0;

  runner.on('pass', function(test) {
    passes++;
    console.log('pass: %s', test.fullTitle());
  });

  runner.on('fail', function(test, err) {
    failures++;
    console.log('fail: %s -- error: %s', test.fullTitle(), err.message);
  });

  runner.on('end', function() {
    console.log('用户自定义报告: %d/%d', passes, passes + failures);
  });
}

/*.在命令行切换目录至项目根目录，执行命令：
“yarn cypress:run --reporter ./reporters/iTesting-custom.js”。
#进入项目根目录
C:\Users\Administrator>E：
E:\>cd Cypress

# 指定reporter为iTesting-custom，生成自定义测试报告
E:\Cypress>yarn cypress:run --reporter ./reporters/iTesting-custom.js
测试运结束，用户自定义报告会显示在Console里
*/