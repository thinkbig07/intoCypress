/*在Cypress项目下的integration文件夹下，新建一个testDynamicRun.js文件，代码如下。
*/

/// <reference types="cypress" />

describe('登录', function () {
    // 此用户名和密码为本地服务器默认。
    const username = 'jane.lane'
    const password = 'password123'
  
context('HTML表单登录测试', function () {
	//让runFlag为0时，此条不运行
      it('登录成功，跳转到dashboard页', function () {
          if(Cypress.env('runFlag')===1){
            cy.visit('http://localhost:7077/login') 
            cy.get('input[name=username]').type(username)
            cy.get('input[name=password]').type(password) 
            cy.get('form').submit()
      
            // 验证登录成功则跳转到/dashboard页面。
            cy.get('h1').should('contain', 'jane.lane')
          }
          else{
              this.skip()
              cy.log("runFlag为0时，此句输出不应被执行")
          }
      })

      it('测试1=1', function () {
        expect(1).to.equal(1)
        })

    })
  })

/*
打开命令行，切换当前目录至项目根目录，执行“yarn cypress:open –env runFlag=0”。
#进入项目根目录
C:\Users\Administrator>E：
E:\>cd Cypress
E:\Cypress>yarn cypress:open –env runFlag=0
然后在TestRunner中选择测试用例“testOnlyTest.js”，点击运行。
*/