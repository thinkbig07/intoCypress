/*
1.在Cypress项目下的integration文件夹下，创建一个子目录autoGenTestLogin，在此目录下新建一个testLogin.data.js文件，代码如下。
*/
//testLogin.data.js
export const testLoginUser = [
    {
        summary: "Login pass",
        username: "jane.lane",
        password: "password123"
    },
    {
        summary: "Login fail",
        username: "iTesting",
        password: "iTesting"
    }
]

/*
2.在子目录autoGenTestLogin下，新建一个testLogin.js文件，代码如下。
*/

/// <reference types="cypress" />

import { testLoginUser } from '../autoGenTestLogin/testLogin.data'

describe('登录', function () {
  // 此用户名和密码为本地服务器默认。
  const username = 'jane.lane'
  const password = 'password123'

  context('HTML表单登录测试', function () {
    for(const user of testLoginUser){
      it(user.summary, function () {
        cy.visit('http://localhost:7077/login') 
        cy.get('input[name=username]').type(user.username)
        cy.get('input[name=password]').type(user.password) 
        cy.get('form').submit()

        cy.get('h1').should('contain', user.username)
      })
    }
  })
})

/*
打开命令行，切换当前目录至项目根目录，执行“yarn cypress:open”。
#进入项目根目录
C:\Users\Administrator>E：
E:\>cd Cypress
E:\Cypress>yarn cypress:open
然后在TestRunner中选择测试文件夹autoGenTestLogin下的用例“testLogin.js”，点击运行。
*/