//testLoginBefore.js
/// <reference types="cypress" />

describe('登录', function () {
    // 此用户名和密码为本地服务器默认。
    const username = 'jane.lane'
    const password = 'password123'
    
    before(function(){
      cy.log('测试前的数据准备')
    })
  
    context('HTML表单登录测试', function () {
  
      it('登录成功，跳转到dashboard页', function () {
        cy.visit('http://localhost:7077/login') 
        cy.get('input[name=username]').type(username)
        cy.get('input[name=password]').type(password) 
        cy.get('form').submit()
  
        // 验证登录成功则跳转到/dashboard页面。
        cy.get('h1').should('contain', 'jane.lane')
      })

      it('新增测试，验证before（）只执行一次', function () {
        expect(1).to.equal(1)
      })
    })
  })
  