//testLoginAfterEach.js
/// <reference types="cypress" />

describe('登录', function () {
    // 此用户名和密码为本地服务器默认。
    const username = 'jane.lane'
    const password = 'password123'
    
    afterEach(function(){
      cy.log('测试后的数据清理')
    })
  
    context('HTML表单登录测试', function () {
  
      it('登录成功，跳转到dashboard页', function () {
        //1个visit命令
        cy.visit('http://localhost:7077/login') 
         //1个get命令，一个type命令
        cy.get('input[name=username]').type(username)
        //1个get命令，一个type命令
        cy.get('input[name=password]').type(password) 
        //1个get命令，一个submit命令
        cy.get('form').submit()
  
        // 验证登录成功则跳转到/dashboard页面。
        // 验证用户名存在。
  
         //一个get命令，一个断言
        cy.get('h1').should('contain', 'jane.lane')
      })
  
      it('新增测试，验证afterEach（）执行次数跟测试用例个数相同', function () {
        expect(1).to.equal(1)
      })
    })
  })