/// <reference types="cypress" />

describe('登录', function () {
  // 此用户名和密码为本地服务器默认。
  const username = 'jane.lane'
  const password = 'password123'

  context('HTML表单登录测试', function () {
    //此条测试不执行
    it.skip('登录成功，跳转到dashboard页', function () {
      cy.visit('http://localhost:7077/login') 
      cy.get('input[name=username]').type(username)
      cy.get('input[name=password]').type(password) 
      cy.get('form').submit()

      // 验证登录成功则跳转到/dashboard页面。
      cy.get('h1').should('contain', 'jane.lane')
    })

    //整个测试集，只有此条测试会执行
    it.only('测试1!=2', function(){
      expect(1).not.to.equal(2)
    })

    //此条测试不执行
    it('测试1=1', function () {
      expect(1).to.equal(1)
      })
  })
})