/// <reference types="cypress" />


//1.箭头函数在 it 中不工作
describe('测试箭头函数', function () {
    beforeEach(function () {
        // wrap ‘hello’到text中
        cy.wrap('hello').as('text')
      })
      
      //it里用了箭头函数后拿不到wrap的text了。
      it('访问不到', ()=> {
        //this.text打印为空
        cy.log(this.text) 
      }) 
})

//2.cypress中不能直接赋值
describe('赋值测试', function () {
    let testVar
    it('testVar返回空', function () {
      cy.visit('https://helloqa.com') 
      cy.contains('首页').then(($el)=>{
        testVar = $el.text()
  //‘首页’第一次被打印出。	
  cy.log(testVar)
  })
  //‘首页’第二次未被打印出。
      cy.log(testVar)
    })
  })


//3.闭包
//保存btn元素的文本信息在txt变量中。 
const txt = $btn.text()

//假设提交form会改变button的文本。
cy.get('form').submit()

// 再次获取button的文本并和之前的文本对比
cy.get('button').should(($btn2) => {
    expect($btn2.text()).not.to.eq(txt)
})


//4. .wrap()和.as()。
describe('a suite', function () {

  beforeEach(function () {
    cy.visit('http://www.helloqa.com')
    cy.contains('首页').then(($el)=>{
    //把$el.text()设置成别名text
        cy.wrap($el.text()).as('text')
        })
    })

  it('does have access to text', function () {
    //使用@get访问别名
    cy.get('@text').then((el)=>{
      cy.log(el)
    })
  })
})

//5. 自定义变量
/*
1) 在 cypress.json()里，env的 配置项里，添加如下设置：
//testVariables是我们自定义的，用来保存运行中生成的变量。
*/

/*
"env": {
    testVariables : {}
}
2)在你的测试代码中使用Cypress.env()来设置和获取变量。
*/
describe('全局变量', function(){
    it('设置全局变量测试',function(){
        cy.visit('http://www.helloqa.com')
        cy.contains('首页'). then(($el)=>{
	//testVariables是一个Array。
		//定义一个新的变量，名为text，把它的值赋为“首页”。
            Cypress.env('testVariables').text = $el.text()
        })
    })

    it('获取全局变量测试',function(){
	//打印出新的变量值。
        cy.log(Cypress.env('testVariables').text)
    })
})