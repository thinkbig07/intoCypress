/*
# 安装
$ npm i puppeteer
# 或者
$ yarn add puppeteer

# 编写测试（名称testExample.js)
# 此用例访问 helloqa 站点并截屏为testExample。
const puppeteer = require('puppeteer');
 (async () => { 
	const browser = await puppeteer.launch(); 
	const page = await browser.newPage(); 
	await page.goto('https://www.helloqa.com'); 
	await page.screenshot({path: testExample.png'}); 
	await browser.close(); 
	})();

# 运行你的用例
$ node testExample.js
*/
