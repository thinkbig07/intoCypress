/* 安装 TestCafe
安装 TestCafe 前，需要确保你的机器上已经安装好 Node.js 和 npm。
# 本地安装
$ npm install --save-dev testcafe

# 全局安装
npm install -g testcafe

# 运行你的用例
$ testcafe chrome {path-to-testfile/}testfile
*/