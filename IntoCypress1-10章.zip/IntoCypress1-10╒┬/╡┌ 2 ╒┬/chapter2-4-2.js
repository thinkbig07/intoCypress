/*
// 安装Node JS 
从以下链接下载并安装，注意选择跟您的操作系统相同的版本https://nodejs.org/en/download/

// 安装Nightwatch:
$ npm install nightwatch --save-dev 

// 安装WebDriver,根据要运行的浏览器不同相应安装:
// 用于Firefox:
$ npm install geckodriver --save-dev
// 用于Chrome:
$ npm install chromedriver --save-dev
// 用于Safari:
$ safaridriver --enable

// 安装Selenium-standalone
$ npm install selenium-standalone --save-dev

// 配置nightwatch.json，nightwatch.conf.js等设置，请参考//https://nightwatchjs.org/gettingstarted//configuration

*/