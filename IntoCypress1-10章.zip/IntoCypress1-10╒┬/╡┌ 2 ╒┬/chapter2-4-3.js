/*
// 全局安装 Protractor
npm install -g protractor

//这将安装两个命令行工具protractor和webdriver-manager。

// 检查版本确保正确安装
$ protractor --version

// 下载必要 binaries
$ webdriver-manager update

// 启动 Selenium Server
$ webdriver-manager start

//这将启动Selenium Server并输出一堆信息日志。您的Protractor测试将向此服务器发送请求以控制本地浏览器。 您可以在http://localhost:4444/wd/hub中查看有关服务器状态的信息。

// 编写好你的测试用例（例如文件名是 test.JS)后。通常你还需要一个配置文件（例如 conf.JS)。
// conf.JS文件内容如下
exports.config = { 
	seleniumAddress: 'http://localhost:4444/wd/hub', 
	specs: [' test.js'] 
};

// 运行你的用例
$ protractor conf.js

*/