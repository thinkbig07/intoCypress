//JavaScript 基础
//author: 关注公众号 “iTeting”，跟随万人技术团一起成长。
function testScript(personList){
    var followNum =personList.length;
    console.log(followNum);
    while(followNum>0){
        const name = personList[followNum-1].name;
        let gender;
        if(personList[followNum-1].gender==='Male'){
            gender = '小哥哥';
        }
        else{
            gender = '小姐姐';
    }
        const welcomeWords = name + gender + '，欢迎关注iTesting';
        console.log(welcomeWords)
        followNum--;
    }

}

var people = [{"name":"kevin","gender":"male"},{"name":"emily","gender":"female"}]

testScript(people)


//闭包概念演示
//author:iTesting
function outer(){
    var name = 'iTesting';
    function inner(){
        console.log(name)
    }
    return inner
}
