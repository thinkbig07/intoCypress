/// <reference types="cypress" />
describe('第 3 个用例', () => {
    it('[smoke]测试 Module API', () => {
      expect('iTesting').to.equal('iTesting')
    })
  })
  